import obpro.cui.Random;

/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class Flat extends Tile {
	private String[] arrTileFlat = { "grass.png", "grass2.png", "grass3.png" };

	public void setRandomImage() {
		this.imageName = "res/"
				+ arrTileFlat[Random.getInt(arrTileFlat.length)];
	}
}
