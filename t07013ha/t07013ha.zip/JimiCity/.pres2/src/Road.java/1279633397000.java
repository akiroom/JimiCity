import obpro.cui.Random;

/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class Road extends Tile {
	private String[] arrRoad = { "road.png" };

	Road() {

	}

	public void setRandomImage() {
		this.imageName = "res/" + arrRoad[Random.getInt(arrRoad.length)];
	}

}
