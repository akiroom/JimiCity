import obpro.cui.Random;

/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class Building extends Tile {
	private String[] arrTileBuilding = { "b0.png", "b1.png", "b2.png",
			"b3.png", "b4.png", "b5.png", "b6.png", "b7.png", "b8.png",
			"b9.png", "b10.png", "b11.png", "b12.png" };

	// �N������
	public static void main(String[] args) {
		Building building = new Building();
		building.main();
	}

	public void setRandomImage() {
		this.imageName = "res/"
				+ arrTileBuilding[Random.getInt(arrTileBuilding.length)];
	}
}
