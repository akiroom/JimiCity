package obpro.gui;

import java.awt.Color;

/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class MyBCanvas extends BCanvas {
	private CanvasPanel canvasPanel;

	public MyBCanvas(CanvasPanel canvasPanel, CanvasKeyEventHandler keyHandler,
			CanvasMouseEventHandler mouseHandler) {
		canvasPanel = canvasPanel;
		super(canvasPanel, keyHandler, mouseHandler);
	}

	public void drawText(Color color, String text, double x, double y) {
		canvasPanel.drawText(color, text, x, y);
	}
}
