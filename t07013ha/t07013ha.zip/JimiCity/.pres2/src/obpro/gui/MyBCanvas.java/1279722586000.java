package obpro.gui;

/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class MyBCanvas extends BCanvas {
	public MyBCanvas(CanvasPanel canvasPanel, CanvasKeyEventHandler keyHandler,
			CanvasMouseEventHandler mouseHandler) {
		super(canvasPanel, keyHandler, mouseHandler);
	}

}
