package General;

import obpro.gui.BCanvas;

public class MyBCanvas extends BCanvas {
	public MyBCanvas(CanvasPanel canvasPanel, CanvasKeyEventHandler keyHandler,
			CanvasMouseEventHandler mouseHandler) {
		super(canvasPanel, keyHandler, mouseHandler);
	}
}
