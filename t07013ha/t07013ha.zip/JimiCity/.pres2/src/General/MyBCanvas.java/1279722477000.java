package General;

import obpro.gui.BCanvas;

public class MyBCanvas extends BCanvas {

}
