package General;

import obpro.gui.BCanvas;
import obpro.gui.CanvasKeyEventHandler;
import obpro.gui.CanvasMouseEventHandler;
import obpro.gui.CanvasPanel;

/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class MyBCanvas extends BCanvas {
	public MyBCanvasCanvasPanel canvasPanel, CanvasKeyEventHandler keyHandler,
			CanvasMouseEventHandler mouseHandler) {
				super(canvasPanel, keyHandler,
				mouseHandler);
	}
}
