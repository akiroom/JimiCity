package General;

/*
 * �v���O�������F	�v�Z�̂������̊֐�
 * �쐬�ҁF		�H�R���I
 * 
 */

public class Calculation {
	public static double distance(Point a, Point b) {
		return distance(a.x, a.y, b.x, b.y);
	}

	public static double distance(Point a, int x, int y) {
		return distance(a.x, a.y, x, y);
	}

	public static double distance(int x1, int y1, int x2, int y2) {
		Math.sqrt((x1 - x2) ^ 2 + (y1 - y2) ^ 2);
		return 0;
	}

	public double sqrt(double x) {
		double s, last;

		if (x <= 0.0)
			return 0.0;

		if (x > 1)
			s = x;
		else
			s = 1;
		do {
			last = s;
			s = (x / s + s) * 0.5;
		} while (s < last);

		return last;
	}

}
