package TileSets;

import obpro.common.BConverter;
import obpro.common.BStopWatch;
import obpro.cui.Input;
import obpro.cui.Random;
import obpro.file.BFile;
import obpro.file.BFileReader;
import obpro.file.BFileWriter;


/*
 * �v���O�������F 
 * �쐬�ҁF 
 */

public class House extends Tile {
	 "h1.png", "h2.png", "h3.png",
		"h4.png", "h5.png", "h6.png", "h7.png", "h8.png", "h9.png",
		"h10.png", "h11.png", "h12.png", "h12.png", "h13.png", "h14.png",
		"h15.png", "h16.png", "h17.png", "h18.png", "h19.png", "h20.png",
		"h21.png", "h22.png", "h23.png", "h24.png", "h25.png"

}
