import obpro.cui.Random;
import obpro.gui.BCanvas;

/*
 * �v���O�������F	City�N���X�F�X���̂��Ǘ����Ă���N���X
 * �쐬�ҁF		
 */

public class City {
	// �e�^�C��
	private Tile[][] _arrTiles;
	private int _tileWidth = 32;
	private int _tileHeight = 9;
	private int _tileGraphicHeight = 128;

	// �R���X�g���N�^
	City(int cityWidth, int cityHeight, int tileWidth, int tileHeight,
			int tileGraphicHeight) {
		_arrTiles = new Tile[cityHeight][cityWidth];
		for (int y = 0; y < cityHeight; y++) {
			for (int x = 0; x < cityWidth; x++) {
				_arrTiles[y][x] = new Tile();
				int n = Random.getInt(4);
				switch (n) {
				case 0:
					_arrTiles[y][x].imageName = "res/grass.png";
					break;
				case 1:
					_arrTiles[y][x].imageName = "res/grass2.png";
					break;
				case 2:
					_arrTiles[y][x].imageName = "res/grass3.png";
					break;
				case 3:
					_arrTiles[y][x].imageName = "res/dirt.png";
					break;
				}
				System.out.println(n);
			}
		}
		_tileWidth = tileWidth;
		_tileHeight = tileHeight;
		_tileGraphicHeight = tileGraphicHeight;
	}

	// �X�̌i�F��`��
	public void draw(BCanvas canvas, int viewX, int viewY, int viewWidth,
			int viewHeight) {
		Tile tile = null;
		// int width = 0;
		// int height = _arrTiles.length;
		int isZurashi = 0;
		canvas.clear();

		// �^�C�����ƂɃ��[�v���܂킷
		int x;
		int y = viewY;
		while ((y - viewY) * _tileHeight < viewHeight) {
			if (y >= _arrTiles.length)
				break;
			x = viewX;
			if (y % 2 == 0)
				isZurashi = _tileWidth / 2;
			else
				isZurashi = 0;
			while ((x - viewX) * _tileWidth < viewWidth) {
				if (x >= _arrTiles[y].length)
					break;
				tile = _arrTiles[y][x];
				int tx = x * _tileWidth + isZurashi - viewX * _tileWidth;
				int ty = (y + 1) * _tileHeight - _tileGraphicHeight - viewY
						* _tileHeight;
				canvas.drawImage(tile.imageName, tx - _tileWidth, ty,
						_tileWidth, _tileGraphicHeight);
				x++;
			}
			y++;
		}
	}

	public int getWidth() {
		return _arrTiles[0].length;
	}

	public int getHeight() {
		return _arrTiles.length;
	}
}
