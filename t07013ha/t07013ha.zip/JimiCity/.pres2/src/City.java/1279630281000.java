import obpro.cui.Random;
import obpro.gui.BCanvas;

/*
 * �v���O�������F	City�N���X�F�X���̂��Ǘ����Ă���N���X
 * �쐬�ҁF		
 */

public class City {
	// �e�^�C��
	private Tile[][] _arrTiles;
	private int _tileWidth = 32;
	private int _tileHeight = 9;
	private int _tileGraphicHeight = 128;

	// �R���X�g���N�^
	City(int cityWidth, int cityHeight, int tileWidth, int tileHeight,
			int tileGraphicHeight) {
		_arrTiles = new Tile[cityHeight][cityWidth];
		for (int y = 0; y < cityHeight; y++) {
			for (int x = 0; x < cityWidth; x++) {
				_arrTiles[y][x] = new Tile();
				int n = Random.getInt(4);
				setTileRandom(x, y);
				System.out.println(n);
			}
		}
		drawRandomRoad();
		drawRandomRoad();
		drawRandomRoad();
		_tileWidth = tileWidth;
		_tileHeight = tileHeight;
		_tileGraphicHeight = tileGraphicHeight;
	}

	// �X�̌i�F��`��
	public void draw(BCanvas canvas, int viewX, int viewY, int viewWidth,
			int viewHeight) {
		Tile tile = null;
		int isZurashi = 0;
		canvas.clear();

		// �^�C�����ƂɃ��[�v���܂킷
		for (int y = viewY; (y - viewY - 1) * _tileHeight < viewHeight; y++) {
			if (y >= _arrTiles.length)
				break;
			if (y % 2 == 0)
				isZurashi = _tileWidth / 2;
			else
				isZurashi = 0;
			for (int x = viewX; (x - viewX - 1) * _tileWidth < viewWidth; x++) {
				if (x >= _arrTiles[y].length)
					break;
				tile = _arrTiles[y][x];
				int tx = x * _tileWidth + isZurashi - viewX * _tileWidth;
				int ty = (y + 1) * _tileHeight - _tileGraphicHeight - viewY
						* _tileHeight;
				canvas.drawImage(tile.imageName, tx - _tileWidth, ty);
			}
		}
	}

	// �X�̉���
	public int getWidth() {
		return _arrTiles[0].length;
	}

	// �X�̍���
	public int getHeight() {
		return _arrTiles.length;
	}

	// �w�肵�����W�Ƀ^�C����ݒ�
	public void setTile(int x, int y, Tile tile) {
		_arrTiles[y][x] = tile;
	}

	// �w�肳�ꂽ���W�������_���ȗv�f�ɐ؂�ւ���
	public void setTileRandom(int x, int y) {
		int rnd = Random.getInt(8);
		if (rnd < 7)
			_arrTiles[y][x] = new Building();
		else
			_arrTiles[y][x] = new Flat();
		_arrTiles[y][x].setRandomImage();
	}

	public void drawRandomRoad() {
		int rx = Random.getInt(_arrTiles[0].length);
		int ry = Random.getInt(_arrTiles.length);

		int which = Random.getInt(2);

		int nx = rx;
		int ny = ry;
		while (true) {
			if (which == 0) {
				nx--;
				ny--;
			} else {
				nx++;
				ny--;
			}
			if (ny < 0)
				break;
			if (nx < 0)
				break;
			if (nx > _arrTiles[0].length - 1)
				break;
			_arrTiles[ny][nx].imageName = "res/road.png";
		}
		nx = rx;
		ny = ry;
		while (true) {
			if (which == 0) {
				nx++;
				ny++;
			} else {
				nx--;
				ny++;
			}
			if (nx < 0)
				break;
			if (nx > _arrTiles[0].length - 1)
				break;
			if (ny > _arrTiles.length - 1)
				break;
			_arrTiles[ny][nx].imageName = "res/road.png";
		}

	}

	public int getTileWidth() {
		return _tileWidth;
	}

	public int getTileHeight() {
		return _tileHeight;
	}
}
