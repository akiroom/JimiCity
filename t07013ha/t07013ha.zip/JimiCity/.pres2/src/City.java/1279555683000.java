import obpro.cui.Random;
import obpro.gui.BCanvas;

/*
 * �v���O�������F	City�N���X�F�X���̂��Ǘ����Ă���N���X
 * �쐬�ҁF		
 */

public class City {
	// �e�^�C��
	private Tile[][] _arrTiles;
	private int _tileWidth = 32;
	private int _tileHeight = 9;
	private int _tileGraphicHeight = 128;

	// �R���X�g���N�^
	City(int cityWidth, int cityHeight, int tileSize, int tileGraphicHeight) {
		_arrTiles = new Tile[cityHeight][cityWidth];
		for (int y = 0; y < cityHeight; y++) {
			for (int x = 0; x < cityWidth; x++) {
				_arrTiles[y][x] = new Tile();
				int n = Random.getInt(4);
				switch (n) {
				case 0:
					_arrTiles[y][x].imageName = "res/grass.png";
					break;
				case 1:
					_arrTiles[y][x].imageName = "res/grass2.png";
					break;
				case 2:
					_arrTiles[y][x].imageName = "res/grass3.png";
					break;
				case 3:
					_arrTiles[y][x].imageName = "res/dirt.png";
					break;
				}
				System.out.println(n);
			}
		}
		_tileSize = tileSize;
		_tileGraphicHeight = tileGraphicHeight;
	}

	// �X�̌i�F��`��
	public void draw(BCanvas canvas, int viewX, int viewY, int viewWidth,
			int viewHeight) {
		Tile tile = null;
		int width = 0;
		int height = _arrTiles.length;
		int isZurashi = 0;
		canvas.clear();

		// �^�C�����ƂɃ��[�v���܂킷
		int x = 0;
		int y = 0;
		while (y *  < viewY){
			x=0;
			
		}
		for (int y = 0; y < height; y++) {
			width = _arrTiles[y].length;
			if (y % 2 == 0)
				isZurashi = _tileWidth / 2 + 1;
			else
				isZurashi = 0;
			for (int x = 0; x < width; x++) {
				// �^�C���̏����i�[
				tile = _arrTiles[y][x];
				int tx = x * _tileWidth + isZurashi;
				int ty = (y + 1) * _tileHeight - _tileGraphicHeight;
				canvas.drawImage(tile.imageName, tx * 2, ty * 2, _tileWidth * 2,
						_tileGraphicHeight * 2);
			}
		}
	}
}
