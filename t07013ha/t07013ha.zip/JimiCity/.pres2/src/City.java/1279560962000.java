import obpro.cui.Random;
import obpro.gui.BCanvas;

/*
 * �v���O�������F	City�N���X�F�X���̂��Ǘ����Ă���N���X
 * �쐬�ҁF		
 */

public class City {
	// �e�^�C��
	private Tile[][] _arrTiles;
	private int _tileWidth = 32;
	private int _tileHeight = 9;
	private int _tileGraphicHeight = 128;

	private String[] arrTileFlat = { "grass.png", "grass2.png", "grass3.png" };
	private String[] arrTileBuilding = { "b0.png", "b1.png", "b2.png",
			"b3.png", "b4.png", "b5.png", "b6.png", "b7.png", "b8.png",
			"b9.png", "b10.png", "b11.png", "b12.png" };

	// �R���X�g���N�^
	City(int cityWidth, int cityHeight, int tileWidth, int tileHeight,
			int tileGraphicHeight) {
		_arrTiles = new Tile[cityHeight][cityWidth];
		for (int y = 0; y < cityHeight; y++) {
			for (int x = 0; x < cityWidth; x++) {
				_arrTiles[y][x] = new Tile();
				int n = Random.getInt(4);
				setTileRandom(x, y);
				System.out.println(n);
			}
		}
		_tileWidth = tileWidth;
		_tileHeight = tileHeight;
		_tileGraphicHeight = tileGraphicHeight;
	}

	// �X�̌i�F��`��
	public void draw(BCanvas canvas, int viewX, int viewY, int viewWidth,
			int viewHeight) {
		Tile tile = null;
		// int width = 0;
		// int height = _arrTiles.length;
		int isZurashi = 0;
		canvas.clear();

		// �^�C�����ƂɃ��[�v���܂킷
		int x;
		int y = viewY;
		while ((y - viewY - 1) * _tileHeight < viewHeight) {
			if (y >= _arrTiles.length)
				break;
			x = viewX;
			if (y % 2 == 0)
				isZurashi = _tileWidth / 2;
			else
				isZurashi = 0;
			while ((x - viewX - 1) * _tileWidth < viewWidth) {
				if (x >= _arrTiles[y].length)
					break;
				tile = _arrTiles[y][x];
				int tx = x * _tileWidth + isZurashi - viewX * _tileWidth;
				int ty = (y + 1) * _tileHeight - _tileGraphicHeight - viewY
						* _tileHeight;
				canvas.drawImage(tile.imageName, tx - _tileWidth, ty);
				x++;
			}
			y++;
		}
	}

	public int getWidth() {
		return _arrTiles[0].length;
	}

	public int getHeight() {
		return _arrTiles.length;
	}

	public void setTile(int x, int y, Tile tile) {
		_arrTiles[y][x] = tile;
	}

	public void setTileRandom(int x, int y) {
		String fileName = "";
		int rnd = Random.getInt(8);
		if (rnd < 1)
			fileName = arrTileFlat[Random.getInt(arrTileFlat.length)];
		else
			fileName = arrTileBuilding[Random.getInt(arrTileBuilding.length)];
		System.out.println(fileName);
		if (fileName == "")
			fileName = "res/grass.png";
		fileName = "res/" + fileName;
		_arrTiles[y][x].imageName = fileName;
	}

	public void drawRandomRoad() {
		int isHorizontal = Random.getInt(2);
		int selectedLine;
		int max;
		if (isHorizontal == 0) {
			max = getHeight();
			selectedLine = Random.getInt(getWidth());
		} else {
			max = getWidth();
			selectedLine = Random.getInt(getHeight());
		}
		for (int i = 0; i < max; i++) {
			if (which == 0)
				Tile tile = _arrTiles[i][selectedLine];
		}
	}
}
